package com.example.wisatakalsel.model

val dummyTourEmpty = listOf<Int>(1,2,3,4)